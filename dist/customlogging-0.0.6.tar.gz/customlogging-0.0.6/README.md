A Python3 module that allows you to log to stdout, files as well as SMTP

To install local packages pip3 install customlogging --no-index --find-links customlogging-0.0.1.tar.gz