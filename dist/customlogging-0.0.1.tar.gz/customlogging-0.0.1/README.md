A Python3 module that allows you to log to stdout, files as well as SMTP
